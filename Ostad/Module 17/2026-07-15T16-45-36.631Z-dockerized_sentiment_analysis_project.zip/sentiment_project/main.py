"""
Sentiment Analysis API
======================
FastAPI + HuggingFace + Redis Cache
Everything runs inside Docker via docker compose up --build

Endpoints:
  GET  /              → welcome + links
  GET  /health        → health check (Redis + model status)
  POST /analyze       → single text sentiment
  POST /analyze/batch → batch texts, deduplication via cache
  GET  /stats         → cache hit/miss stats
  GET  /docs          → auto-generated Swagger UI
"""

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from transformers import pipeline
import redis
import json
import hashlib
import time
import os

# App setup
app = FastAPI(
    title="Sentiment Analysis API",
    description="HuggingFace sentiment analysis with Redis caching and Nginx load balancing",
    version="1.0.0",
)

# Instance identity (set via INSTANCE env var in docker-compose)
INSTANCE_ID = os.environ.get("INSTANCE", f"instance_{os.getpid()}")
START_TIME   = time.time()

# Redis connection
REDIS_HOST = os.environ.get("REDIS_HOST", "redis")   # "redis" = Docker service name
REDIS_PORT = int(os.environ.get("REDIS_PORT", 6379))
CACHE_TTL  = int(os.environ.get("CACHE_TTL", 300))   # 5 minutes default

r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=True)

# Load model ONCE at startup
print(f"[{INSTANCE_ID}] Loading sentiment model...")
model = pipeline(
    "sentiment-analysis",
    model="distilbert-base-uncased-finetuned-sst-2-english",
)
print(f"[{INSTANCE_ID}] ✅ Model ready!")

# In-memory stats
_stats = {"hits": 0, "misses": 0, "requests": 0}


# Pydantic schemas
class TextInput(BaseModel):
    text: str = Field(..., min_length=1, max_length=5000,
                      example="FastAPI and Docker together are incredibly powerful!")


class BatchInput(BaseModel):
    texts: list[str] = Field(..., min_items=1, max_items=50,
                              example=["I love this!", "This is terrible.", "I love this!"])


class SentimentResult(BaseModel):
    text:       str
    label:      str
    score:      float
    from_cache: bool
    instance:   str


# Cache helpers
def make_key(text: str) -> str:
    """MD5 hash of normalised text → compact, consistent Redis key."""
    normalised = text.lower().strip()
    h = hashlib.md5(normalised.encode()).hexdigest()
    return f"sentiment:{h}"


def get_cached(text: str):
    """Return cached result dict or None."""
    try:
        raw = r.get(make_key(text))
        if raw:
            _stats["hits"] += 1
            return json.loads(raw)
    except redis.RedisError:
        pass
    return None


def set_cache(text: str, result: dict):
    """Store result in Redis with TTL."""
    try:
        r.setex(make_key(text), CACHE_TTL, json.dumps(result))
    except redis.RedisError:
        pass


def run_model(text: str) -> dict:
    """Run HuggingFace inference and return structured dict."""
    _stats["misses"] += 1
    raw = model(text)[0]
    return {
        "label": raw["label"],
        "score": round(raw["score"], 4),
    }


# Routes
@app.get("/", response_class=HTMLResponse)
def root():
    uptime = round(time.time() - START_TIME, 1)
    return f"""
    <html><body style="font-family:monospace;background:#0f1923;color:#e8edf5;padding:40px">
    <h1 style="color:#f97316">⚡ Sentiment Analysis API</h1>
    <p>Served by: <b style="color:#14b8a6">{INSTANCE_ID}</b> | Uptime: {uptime}s</p>
    <ul>
      <li><a href="/docs" style="color:#3b82f6">📖 Interactive API Docs (Swagger)</a></li>
      <li><a href="/health" style="color:#22c55e">💚 Health Check</a></li>
      <li><a href="/stats" style="color:#a855f7">📊 Cache Statistics</a></li>
    </ul>
    <p style="color:#8b949e">POST /analyze  →  single text<br>
    POST /analyze/batch  →  up to 50 texts</p>
    </body></html>
    """


@app.get("/health")
def health():
    """Health check — Nginx uses this to route around dead instances."""
    redis_ok = False
    try:
        r.ping()
        redis_ok = True
    except redis.RedisError:
        pass

    return {
        "status":      "healthy" if redis_ok else "degraded",
        "instance":    INSTANCE_ID,
        "model":       "loaded",
        "redis":       "connected" if redis_ok else "disconnected",
        "uptime_secs": round(time.time() - START_TIME, 1),
    }


@app.post("/analyze", response_model=SentimentResult)
def analyze(body: TextInput):
    """
    Analyze a single text.
    - Cache hit  → instant return, no model run
    - Cache miss → HuggingFace inference, store in Redis for 5 min
    """
    _stats["requests"] += 1

    cached = get_cached(body.text)
    if cached:
        return SentimentResult(
            text=body.text,
            label=cached["label"],
            score=cached["score"],
            from_cache=True,
            instance=INSTANCE_ID,
        )

    result = run_model(body.text)
    set_cache(body.text, result)

    return SentimentResult(
        text=body.text,
        label=result["label"],
        score=result["score"],
        from_cache=False,
        instance=INSTANCE_ID,
    )


@app.post("/analyze/batch")
def analyze_batch(body: BatchInput):
    """
    Analyze multiple texts efficiently.
    Duplicate texts are computed only once — cache handles deduplication.
    """
    _stats["requests"] += len(body.texts)
    results = []

    for text in body.texts:
        cached = get_cached(text)
        if cached:
            results.append({
                "text":       text,
                "label":      cached["label"],
                "score":      cached["score"],
                "from_cache": True,
            })
        else:
            result = run_model(text)
            set_cache(text, result)
            results.append({
                "text":       text,
                "label":      result["label"],
                "score":      result["score"],
                "from_cache": False,
            })

    cache_hits = sum(1 for r in results if r["from_cache"])
    return {
        "instance":      INSTANCE_ID,
        "total":         len(results),
        "cache_hits":    cache_hits,
        "model_calls":   len(results) - cache_hits,
        "hit_rate":      f"{round(cache_hits / len(results) * 100, 1)}%",
        "results":       results,
    }


@app.get("/stats")
def stats():
    """Cache and performance statistics."""
    total = _stats["hits"] + _stats["misses"]
    hit_rate = round(_stats["hits"] / max(total, 1) * 100, 1)

    cached_keys = 0
    try:
        cached_keys = len(r.keys("sentiment:*"))
    except redis.RedisError:
        pass

    return {
        "instance":      INSTANCE_ID,
        "total_requests": _stats["requests"],
        "cache_hits":    _stats["hits"],
        "cache_misses":  _stats["misses"],
        "hit_rate":      f"{hit_rate}%",
        "keys_in_redis": cached_keys,
        "model_calls_saved": _stats["hits"],
        "cache_ttl_secs": CACHE_TTL,
    }


@app.delete("/cache/clear")
def clear_cache():
    """Clear all sentiment cache entries from Redis."""
    try:
        keys = r.keys("sentiment:*")
        if keys:
            r.delete(*keys)
        _stats["hits"] = 0
        _stats["misses"] = 0
        return {"cleared": len(keys), "message": "Cache cleared"}
    except redis.RedisError as e:
        raise HTTPException(status_code=503, detail=f"Redis error: {e}")
