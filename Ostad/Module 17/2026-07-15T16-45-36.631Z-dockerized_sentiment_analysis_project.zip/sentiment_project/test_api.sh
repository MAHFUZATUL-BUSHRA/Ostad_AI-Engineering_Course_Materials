#!/bin/bash
# ================================================================
# test_api.sh — Step-by-step demo script for class
# Run after: docker compose up --build
# ================================================================

BASE="http://localhost:8080"
LINE="─────────────────────────────────────────────────"

echo ""
echo "⚡ Sentiment API — Docker Demo Tests"
echo "$LINE"

# ── STEP 1: Health Check ──────────────────────────────────────────
echo ""
echo "📍 STEP 1: Health Check (which instance responded?)"
echo "   curl $BASE/health"
echo ""
curl -s $BASE/health | python3 -m json.tool
echo ""

# ── STEP 2: Single analysis (first call = model runs) ─────────────
echo "$LINE"
echo "📍 STEP 2: First sentiment call (CACHE MISS — model runs)"
echo "   POST /analyze"
echo ""
curl -s -X POST "$BASE/analyze" \
  -H "Content-Type: application/json" \
  -d '{"text": "FastAPI and Docker together are incredibly powerful!"}' \
  | python3 -m json.tool
echo ""

# ── STEP 3: Same text again (cache hit) ───────────────────────────
echo "$LINE"
echo "📍 STEP 3: Same text again (CACHE HIT — instant!)"
echo ""
curl -s -X POST "$BASE/analyze" \
  -H "Content-Type: application/json" \
  -d '{"text": "FastAPI and Docker together are incredibly powerful!"}' \
  | python3 -m json.tool
echo ""

# ── STEP 4: Load balancing — 6 requests, watch instance alternate ──
echo "$LINE"
echo "📍 STEP 4: Load Balancing — 6 requests (watch 'instance' field)"
echo ""
for i in $(seq 1 6); do
  echo "  Request $i:"
  curl -s -X POST "$BASE/analyze" \
    -H "Content-Type: application/json" \
    -d "{\"text\": \"Request number $i — testing load balancing\"}" \
    | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'    instance={d[\"instance\"]}  from_cache={d[\"from_cache\"]}  label={d[\"label\"]}')"
done
echo ""

# ── STEP 5: Batch with duplicates ──────────────────────────────────
echo "$LINE"
echo "📍 STEP 5: Batch analysis — duplicates handled via cache"
echo ""
curl -s -X POST "$BASE/analyze/batch" \
  -H "Content-Type: application/json" \
  -d '{
    "texts": [
      "I absolutely love this product!",
      "This is the worst experience ever.",
      "I absolutely love this product!",
      "Docker makes deployment so easy.",
      "This is the worst experience ever."
    ]
  }' | python3 -m json.tool
echo ""

# ── STEP 6: Stats ──────────────────────────────────────────────────
echo "$LINE"
echo "📍 STEP 6: Cache stats — see model_calls_saved"
echo ""
curl -s "$BASE/stats" | python3 -m json.tool
echo ""

# ── STEP 7: Kill api1 and show fault tolerance ─────────────────────
echo "$LINE"
echo "📍 STEP 7: Kill api1 — all traffic moves to api2 automatically"
echo "   Run in another terminal: docker stop sentiment-api1"
echo "   Then run these 3 requests:"
echo ""
for i in 1 2 3; do
  result=$(curl -s "$BASE/health" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('instance','?'))")
  echo "  Request $i → served by: $result"
  sleep 0.5
done

echo ""
echo "$LINE"
echo "✅ Demo complete!"
echo ""
echo "🔗 Useful URLs:"
echo "   Swagger UI:    http://localhost:8080/docs"
echo "   Health check:  http://localhost:8080/health"
echo "   Stats:         http://localhost:8080/stats"
echo "   Redis CLI:     docker exec -it sentiment-redis redis-cli"
echo ""
echo "🛑 To stop everything: docker compose down"
