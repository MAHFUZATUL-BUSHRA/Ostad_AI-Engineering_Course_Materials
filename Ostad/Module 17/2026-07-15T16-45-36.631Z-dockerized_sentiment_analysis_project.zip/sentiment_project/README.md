# Sentiment Analysis API — Full Docker Stack

A production-style FastAPI application demonstrating:
- **HuggingFace** sentiment analysis (DistilBERT)
- **Redis** caching with TTL and MD5 key hashing
- **Nginx** load balancing across two API instances
- **Docker Compose** single-command deployment

## Architecture

```
Client → Nginx :8080 → api1 :8000 ─┐
                    → api2 :8000 ─┤→ Redis :6379 (shared cache)
```

## 🚀 Quick Start (One Command)

```bash
docker compose up --build
```

First run downloads model weights (~260MB) and bakes them into the image.
Takes 3–5 minutes on first build. Subsequent builds: under 30 seconds.

## 🔗 Endpoints

| URL | Description |
|-----|-------------|
| http://localhost:8080 | Welcome page |
| http://localhost:8080/docs | Swagger UI (interactive API docs) |
| http://localhost:8080/health | Health check |
| http://localhost:8080/stats | Cache hit/miss statistics |
| http://localhost:8080/analyze | POST — single text |
| http://localhost:8080/analyze/batch | POST — up to 50 texts |
| http://localhost:8001/docs | api1 direct (bypasses Nginx) |
| http://localhost:8002/docs | api2 direct (bypasses Nginx) |

## 🧪 Demo Test Script

```bash
chmod +x test_api.sh
bash test_api.sh
```

## 📋 Step-by-Step Demo for Class

### Step 1 — Start everything
```bash
docker compose up --build
# Wait for "Model ready!" in both api1 and api2 logs
```

### Step 2 — Health check
```bash
curl http://localhost:8080/health
# See: "instance": "api1" or "api2"
```

### Step 3 — First sentiment call (cache MISS)
```bash
curl -X POST http://localhost:8080/analyze \
  -H "Content-Type: application/json" \
  -d '{"text": "FastAPI is amazing!"}'
# See: "from_cache": false
```

### Step 4 — Same text again (cache HIT)
```bash
curl -X POST http://localhost:8080/analyze \
  -H "Content-Type: application/json" \
  -d '{"text": "FastAPI is amazing!"}'
# See: "from_cache": true  ← instant!
```

### Step 5 — Load balancing (watch instance alternate)
```bash
for i in {1..6}; do
  curl -s http://localhost:8080/health | python3 -m json.tool
done
# Watch "instance" alternate between api1 and api2
```

### Step 6 — Batch with duplicates
```bash
curl -X POST http://localhost:8080/analyze/batch \
  -H "Content-Type: application/json" \
  -d '{"texts": ["I love this!", "I hate this!", "I love this!"]}'
# "I love this!" appears twice — only computed once!
# See: "cache_hits": 1, "model_calls": 2
```

### Step 7 — Fault tolerance demo
```bash
# Kill api1
docker stop sentiment-api1

# All requests now go to api2 — no downtime!
curl http://localhost:8080/health
# "instance": "api2" every time

# Bring api1 back
docker start sentiment-api1

# Load balancing resumes automatically
```

### Step 8 — Inspect Redis live
```bash
docker exec -it sentiment-redis redis-cli
> KEYS *                   # see all cache keys
> TTL sentiment:a3f4...    # seconds remaining
> GET sentiment:a3f4...    # see cached JSON
> DBSIZE                   # total keys in Redis
```

### Step 9 — Cache stats
```bash
curl http://localhost:8080/stats
# See: hit_rate, model_calls_saved, keys_in_redis
```

### Step 10 — Stop everything
```bash
docker compose down
```

## 🐳 Useful Docker Commands

```bash
# See all running containers
docker compose ps

# Follow logs for one service
docker compose logs -f api1

# Open shell inside api1
docker exec -it sentiment-api1 bash

# Rebuild only if Dockerfile or requirements changed
docker compose build

# Scale to 3 API instances (update nginx.conf too)
docker compose up --scale api1=1 api2=1 --build
```

## 📁 Project Files

```
sentiment_project/
├── main.py              ← FastAPI app with Redis caching
├── requirements.txt     ← Python dependencies
├── Dockerfile           ← Container definition
├── docker-compose.yml   ← Full stack: api1 + api2 + redis + nginx
├── nginx.conf           ← Load balancer config
├── .dockerignore        ← Files excluded from Docker build
└── test_api.sh          ← Demo test script
```
