"""
DEMO 4 — Nginx Load Balancing (Local)
========================================
One FastAPI app that reports WHICH server instance served the request.
Run two copies on different ports → Nginx distributes traffic.

HOW TO RUN:
  # 1. Install dependencies
  uv add fastapi uvicorn

  # 2. Install Nginx
  #    Mac:   brew install nginx
  #    Linux: sudo apt install nginx
  #    Windows: choco install nginx

  # 3. Copy nginx.conf (in this folder) to a known path
  #    Then start Nginx pointing at it:
  #    Mac/Linux:
  #    nginx -c $(pwd)/nginx.conf
  
  #    Windows:
  #    cd C:\tools\nginx-1.31.2
  #    .\nginx.exe -c F:\ostad\Module_17_batch_6\fastapi_demos\fastapi-redis-demo\nginx.conf

  # 4. Terminal A — Server 1
  $env:INSTANCE="Server_1"; uv run uvicorn demo_04_lb:app --host 127.0.0.1 --port 8000

  # 5. Terminal B — Server 2
  $env:INSTANCE="Server_2"; uv run uvicorn demo_04_lb:app --host 127.0.0.1 --port 8001

  # 6. Test load balancing (Nginx listens on :8080)
  for i in {1..6}; do curl -s http://127.0.0.1:8080/info | python3 -m json.tool; done

EXPECTED OUTPUT:
  Request 1 → served_by: Server_1
  Request 2 → served_by: Server_2
  Request 3 → served_by: Server_1
  ... (Round Robin)
"""

from fastapi import FastAPI, Request
import os
import time
import socket

app = FastAPI(title="Demo 4 — Load Balanced Server", version="1.0")

# ── Instance identity ─────────────────────────────────────────────
INSTANCE_ID = os.environ.get("INSTANCE", f"server_{os.getpid()}")
START_TIME   = time.time()
request_count = 0


# ── Routes ──────────────────────────────────────────────────────
@app.get("/info")
def info(request: Request):
    """
    Returns which server instance handled this request.
    When Nginx round-robins, you'll see Server_1 / Server_2 alternating.
    """
    global request_count
    request_count += 1

    return {
        "served_by":     INSTANCE_ID,
        "pid":           os.getpid(),
        "hostname":      socket.gethostname(),
        "request_number": request_count,
        "uptime_seconds": round(time.time() - START_TIME, 1),
        "client_ip":     request.client.host,
    }


@app.get("/compute")
def compute(n: int = 5):
    """Heavy computation — demonstrates load is shared across servers."""
    time.sleep(1)   # Simulate ML inference
    return {
        "served_by": INSTANCE_ID,
        "input":     n,
        "result":    n * n,
    }


@app.get("/health")
def health():
    """Health check — Nginx uses this to detect dead servers."""
    return {
        "status":     "healthy",
        "instance":   INSTANCE_ID,
        "requests":   request_count,
    }
