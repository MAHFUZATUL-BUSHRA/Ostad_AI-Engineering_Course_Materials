"""
DEMO 3 — AI Model Inference Cache
====================================
Caches HuggingFace sentiment analysis results in Redis using
an MD5 hash of the input text as the cache key.

Same text submitted 1000 times = 999 GPU calls saved.

HOW TO RUN:
  # 1. Start Redis
  docker run -d -p 127.0.0.1:6379:6379 --name redis-demo redis

  # 2. Install dependencies
  uv add fastapi uvicorn redis transformers torch

  # 3. Start the API (first run downloads the model ~250MB)
  uv run uvicorn demo_03_model_cache:app --reload

TEST:
  # First call — SLOW (model download + inference ~1-3s)
  curl -X POST "http://127.0.0.1:8000/analyze" \
       -H "Content-Type: application/json" \
       -d '{"text": "FastAPI is absolutely amazing!"}'

  # Second call — INSTANT (from Redis cache)
  curl -X POST "http://127.0.0.1:8000/analyze" \
       -H "Content-Type: application/json" \
       -d '{"text": "FastAPI is absolutely amazing!"}'

  # Check cache stats
  curl "http://127.0.0.1:8000/stats"

  # Batch analyze (with caching)
  curl -X POST "http://127.0.0.1:8000/analyze-batch" \
       -H "Content-Type: application/json" \
       -d '{"texts": ["I love this!", "This is terrible.", "I love this!"]}'
"""

from fastapi import FastAPI
from pydantic import BaseModel
from transformers import pipeline
import redis
import json
import hashlib
import time

app = FastAPI(title="Demo 3 — Model Inference Cache", version="1.0")

# ── Redis connection ─────────────────────────────────────────────
r = redis.Redis(host="127.0.0.1", port=6379, db=0, decode_responses=True)

# ── Load the model ONCE at startup ──────────────────────────────
# This is important: load model once globally, not per request!
print("⏳ Loading sentiment model...")
model = pipeline("sentiment-analysis")
print("✅ Model loaded!")

MODEL_CACHE_TTL = 300   # Cache results for 5 minutes
_stats = {"hits": 0, "misses": 0}


# ── Pydantic input models ────────────────────────────────────────
class AnalyzeRequest(BaseModel):
    text: str


class BatchRequest(BaseModel):
    texts: list[str]


# ── Cache key: MD5 hash of input text ───────────────────────────
def make_cache_key(text: str) -> str:
    """
    Hash the text → unique short key.
    "I love this!" → "model:a3f4d8e2..."
    Two identical texts always produce the same key.
    """
    text_hash = hashlib.md5(text.lower().strip().encode()).hexdigest()
    return f"model:{text_hash}"


# ── Routes ──────────────────────────────────────────────────────
@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    """
    Sentiment analysis with Redis caching.
    - Cache hit  → return instantly, no model run
    - Cache miss → run model, store result for 5 min
    """
    key = make_cache_key(req.text)

    # Check cache first
    cached = r.get(key)
    if cached:
        _stats["hits"] += 1
        result = json.loads(cached)
        return {
            "text":         req.text,
            "label":        result[0]["label"],
            "score":        round(result[0]["score"], 4),
            "from_cache":   True,
            "ttl_remaining": r.ttl(key),
        }

    # Cache miss — run model
    _stats["misses"] += 1
    start = time.time()
    result = model(req.text)
    elapsed = round(time.time() - start, 3)

    # Store in Redis with TTL
    r.setex(key, MODEL_CACHE_TTL, json.dumps(result))

    return {
        "text":           req.text,
        "label":          result[0]["label"],
        "score":          round(result[0]["score"], 4),
        "from_cache":     False,
        "inference_time": elapsed,
        "cached_for":     f"{MODEL_CACHE_TTL}s",
    }


@app.post("/analyze-batch")
def analyze_batch(req: BatchRequest):
    """
    Batch analysis — each text checked independently against cache.
    Duplicate texts in the batch only get computed once!
    """
    results = []
    for text in req.texts:
        key = make_cache_key(text)
        cached = r.get(key)

        if cached:
            _stats["hits"] += 1
            result = json.loads(cached)
            results.append({
                "text":       text,
                "label":      result[0]["label"],
                "score":      round(result[0]["score"], 4),
                "from_cache": True,
            })
        else:
            _stats["misses"] += 1
            result = model(text)
            r.setex(key, MODEL_CACHE_TTL, json.dumps(result))
            results.append({
                "text":       text,
                "label":      result[0]["label"],
                "score":      round(result[0]["score"], 4),
                "from_cache": False,
            })

    cache_hit_rate = round(_stats["hits"] / max(_stats["hits"] + _stats["misses"], 1) * 100, 1)
    return {
        "results":       results,
        "total":         len(results),
        "cache_hit_rate": f"{cache_hit_rate}%",
    }


@app.get("/stats")
def stats():
    """Show cache performance stats."""
    total = _stats["hits"] + _stats["misses"]
    hit_rate = round(_stats["hits"] / max(total, 1) * 100, 1)
    cached_keys = len(r.keys("model:*"))

    return {
        "total_requests":  total,
        "cache_hits":      _stats["hits"],
        "cache_misses":    _stats["misses"],
        "hit_rate":        f"{hit_rate}%",
        "keys_in_redis":   cached_keys,
        "gpu_calls_saved": _stats["hits"],
    }


@app.delete("/clear-model-cache")
def clear_model_cache():
    """Delete all model result cache entries."""
    keys = r.keys("model:*")
    if keys:
        r.delete(*keys)
    _stats["hits"] = 0
    _stats["misses"] = 0
    return {"deleted_keys": len(keys), "stats_reset": True}


@app.get("/health")
def health():
    try:
        r.ping()
        return {"status": "ok", "model": "loaded", "redis": "connected"}
    except Exception as e:
        return {"status": "degraded", "redis_error": str(e)}
