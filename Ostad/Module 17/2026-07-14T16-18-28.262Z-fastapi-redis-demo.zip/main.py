def main():
    print("Hello from fastapi-redis-demo!")


if __name__ == "__main__":
    main()
