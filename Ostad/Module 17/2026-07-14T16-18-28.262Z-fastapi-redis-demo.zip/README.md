# FastAPI: From Local Model to Production-Ready API
## Demo Code — Complete Setup Guide

---

## 📁 Files in this folder

| File | Demo | What it shows |
|------|------|---------------|
| `demo_01_lru_cache.py` | Demo 1 | In-memory cache with `lru_cache` |
| `demo_02_redis_cache.py` | Demo 2 | Distributed Redis cache with TTL |
| `demo_03_model_cache.py` | Demo 3 | ML model inference cache (HuggingFace) |
| `demo_04_lb.py` | Demo 4 & 5 | FastAPI app that reports which server served the request |
| `nginx.conf` | Demo 4 | Nginx config for local load balancing |
| `docker-compose.yml` | Demo 5 | Docker Compose with Nginx + 2 API instances + Redis |
| `nginx_docker.conf` | Demo 5 | Nginx config inside Docker |
| `Dockerfile` | Demo 5 | Container definition for FastAPI app |

---

## ⚡ One-time Setup

```bash
# Install Python dependencies
pip install fastapi uvicorn redis transformers torch

# Start Redis via Docker (needed for Demo 2, 3, 5)
docker run -d -p 6379:6379 --name redis-demo redis
```

---

## 🟢 Demo 1 — In-Memory Cache (lru_cache)

```bash
uvicorn demo_01_lru_cache:app --reload
```

**Test it:**
```bash
# First call — takes 3 seconds
curl "http://localhost:8000/compute?n=10"

# Second call — instant! (cached)
curl "http://localhost:8000/compute?n=10"

# Check hit/miss stats
curl "http://localhost:8000/cache-info"

# Clear cache
curl -X DELETE "http://localhost:8000/clear-cache"
```

**What to show class:**
- Open `/docs` (Swagger UI) — automatic!
- Call `/compute?n=10` → wait 3s
- Call `/compute?n=10` again → instant
- Show `elapsed_seconds` in response
- Call `/cache-info` → see hits vs misses

---

## 🔴 Demo 2 — Redis Cache

```bash
# Make sure Redis is running first!
uvicorn demo_02_redis_cache:app --reload
```

**Test it:**
```bash
# First call (3s)
curl "http://localhost:8000/expensive?q=fastapi"

# Second call (instant, from Redis)
curl "http://localhost:8000/expensive?q=fastapi"

# See all keys in Redis
curl "http://localhost:8000/redis-keys"

# Manually delete one entry
curl -X DELETE "http://localhost:8000/invalidate?q=fastapi"

# Now first call is slow again (cache was deleted)
curl "http://localhost:8000/expensive?q=fastapi"
```

**What to show class:**
- `from_cache: true` vs `from_cache: false`
- `ttl_remaining` countdown in Redis
- Open Redis CLI: `docker exec -it redis-demo redis-cli`
  - `KEYS *` — see all cached keys
  - `TTL data:fastapi` — seconds remaining
  - `GET data:fastapi` — see the raw JSON

---

## 🤗 Demo 3 — AI Model Inference Cache

```bash
# Model downloads ~250MB on first run
uvicorn demo_03_model_cache:app --reload
```

**Test it:**
```bash
# First call — model runs (~1-3s)
curl -X POST "http://localhost:8000/analyze" \
     -H "Content-Type: application/json" \
     -d '{"text": "FastAPI is absolutely amazing!"}'

# Second call — instant from cache
curl -X POST "http://localhost:8000/analyze" \
     -H "Content-Type: application/json" \
     -d '{"text": "FastAPI is absolutely amazing!"}'

# Batch with duplicates — only unique texts run through model
curl -X POST "http://localhost:8000/analyze-batch" \
     -H "Content-Type: application/json" \
     -d '{"texts": ["I love this!", "This is terrible.", "I love this!", "Great work!"]}'

# Stats — see gpu_calls_saved
curl "http://localhost:8000/stats"
```

**What to show class:**
- Compare `inference_time` (first call) vs `from_cache: true` (second call)
- Show `gpu_calls_saved` in `/stats`
- Point out MD5 hash key in code — identical text = same cache key

---

## ⚖️ Demo 4 — Local Nginx Load Balancing

```bash
# Terminal 1 — Server 1
INSTANCE=Server_1 uvicorn demo_04_lb:app --port 8000

# Terminal 2 — Server 2
INSTANCE=Server_2 uvicorn demo_04_lb:app --port 8001

# Terminal 3 — Nginx (adjust path to nginx.conf)
nginx -c $(pwd)/nginx.conf

# Test — run 6 requests and watch them alternate
for i in {1..6}; do curl -s http://localhost:8080/info | python3 -m json.tool; echo "---"; done
```

**What to show class:**
- Watch `served_by` alternate between `Server_1` and `Server_2`
- Kill Server_1 (`Ctrl+C` in Terminal 1) → all requests now go to Server_2
- Restart Server_1 → load balancing resumes automatically

---

## 🐳 Demo 5 — Docker Compose (Production Simulation)

```bash
# Build and start everything
docker compose up --build

# In another terminal — test
for i in {1..8}; do curl -s http://localhost:8080/info | python3 -m json.tool; echo "---"; done

# Scale to 3 instances (live)
docker compose up --scale api1=1 api2=1 --build

# See all running containers
docker compose ps

# Stop everything
docker compose down
```

**What to show class:**
- `docker compose ps` — show all 4 containers running
- Hit `:8080` — see requests distributed across `api1` and `api2`
- Show this is identical to AWS ELB / GCP Load Balancer setup

---

## 🛑 Stop / Cleanup

```bash
# Stop Redis
docker stop redis-demo && docker rm redis-demo

# Stop Nginx (Demo 4)
nginx -s stop

# Stop Docker Compose (Demo 5)
docker compose down
```

---

## 📊 Quick Reference: Which demo to show first?

| Goal | Demo |
|------|------|
| Fastest to run, most visual impact | Demo 1 (lru_cache) |
| Show TTL and key expiry | Demo 2 (Redis) |
| Real AI / HuggingFace model | Demo 3 (Model cache) |
| Show two servers alternating | Demo 4 (Nginx) |
| Closest to real production | Demo 5 (Docker Compose) |
