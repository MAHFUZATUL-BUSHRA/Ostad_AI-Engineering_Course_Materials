"""
DEMO 2 — Redis Distributed Cache
==================================
Shows how to cache API results in Redis with TTL (auto-expiry).
Unlike lru_cache, Redis persists across restarts and is shared
between multiple server instances.

HOW TO RUN:
  # 1. Start Redis (Docker — easiest)
  docker run -d -p 127.0.0.1:6379:6379 --name redis-demo redis

  # 2. Install dependencies
  uv add fastapi uvicorn redis

  # 3. Start the API
  uv run uvicorn demo_02_redis_cache:app --reload

TEST:
  # First call — SLOW (3 seconds, stored in Redis for 60s)
  curl "http://127.0.0.1:8000/expensive?q=hello"

  # Second call — INSTANT (served from Redis)
  curl "http://127.0.0.1:8000/expensive?q=hello"

  # Check what's in Redis
  curl "http://127.0.0.1:8000/redis-keys"

  # Manually delete a cache entry
  curl -X DELETE "http://127.0.0.1:8000/invalidate?q=hello"
"""

from fastapi import FastAPI, HTTPException
import redis
import json
import time

app = FastAPI(title="Demo 2 — Redis Cache", version="1.0")

# ── Redis connection ─────────────────────────────────────────────
r = redis.Redis(
    host="127.0.0.1",
    port=6379,
    db=0,
    decode_responses=True,   # Return strings not bytes
)

CACHE_TTL = 10  # seconds before cache entry auto-expires


def check_redis():
    """Verify Redis is running — called on startup."""
    try:
        r.ping()
        print("✅ Redis connected!")
    except redis.exceptions.ConnectionError:
        print("❌ Redis not running. Start with: docker run -p 6379:6379 redis")


check_redis()


# ── The expensive operation ──────────────────────────────────────
def expensive_operation(q: str) -> dict:
    """Simulates a slow DB query or ML computation."""
    print(f"[CACHE MISS] Running expensive operation for q='{q}' ...")
    time.sleep(3)
    return {
        "query":    q,
        "response": f"Processed: {q.upper()}",
        "timestamp": time.time(),
    }


# ── Routes ──────────────────────────────────────────────────────
@app.get("/expensive")
def get_data(q: str):
    """
    The core caching pattern:
    1. Build a cache key
    2. Check Redis
    3. If hit → return immediately
    4. If miss → compute, store in Redis, return
    """
    cache_key = f"data:{q}"

    # Step 1: Check cache
    cached = r.get(cache_key)
    if cached:
        result = json.loads(cached)
        result["from_cache"] = True
        result["ttl_remaining"] = r.ttl(cache_key)
        return result

    # Step 2: Cache miss — run expensive operation
    start = time.time()
    result = expensive_operation(q)
    elapsed = round(time.time() - start, 3)

    # Step 3: Store in Redis with TTL
    r.setex(cache_key, CACHE_TTL, json.dumps(result))

    return {
        **result,
        "from_cache":     False,
        "elapsed_seconds": elapsed,
        "cached_for":     f"{CACHE_TTL} seconds",
    }


@app.get("/redis-keys")
def list_keys():
    """Show all cache keys currently stored in Redis."""
    keys = r.keys("data:*")
    return {
        "total_keys": len(keys),
        "keys": [
            {
                "key": k,
                "ttl_seconds": r.ttl(k),
            }
            for k in keys
        ],
    }


@app.delete("/invalidate")
def invalidate(q: str):
    """Manually delete a cache entry before TTL expires."""
    key = f"data:{q}"
    deleted = r.delete(key)
    if deleted:
        return {"message": f"Cache entry '{key}' deleted"}
    raise HTTPException(status_code=404, detail=f"Key '{key}' not found in cache")


@app.delete("/clear-all")
def clear_all():
    """Delete all data: keys from Redis."""
    keys = r.keys("data:*")
    if keys:
        r.delete(*keys)
    return {"deleted": len(keys)}


@app.get("/health")
def health():
    try:
        r.ping()
        return {"status": "ok", "redis": "connected"}
    except Exception as e:
        return {"status": "error", "redis": str(e)}
