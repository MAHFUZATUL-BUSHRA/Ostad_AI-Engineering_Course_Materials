"""
DEMO 1 — In-Memory Cache with lru_cache
========================================
Shows how Python's built-in lru_cache stores results in RAM.

HOW TO RUN:
  uv sync
  uv add fastapi uvicorn
  uv run uvicorn demo_01_lru_cache:app --reload

TEST:
  # First call — SLOW (3 seconds)
  curl "http://localhost:8000/compute?n=10"

  # Second call — INSTANT (cached)
  curl "http://localhost:8000/compute?n=10"

  # Check cache stats
  curl "http://localhost:8000/cache-info"

  # Clear cache
  curl -X DELETE "http://localhost:8000/clear-cache"
"""

from fastapi import FastAPI
from functools import lru_cache
import time

app = FastAPI(title="Demo 1 — LRU Cache", version="1.0")


# ── The heavy computation (simulates ML inference) ──────────────
@lru_cache(maxsize=50)       # Stores up to 50 unique results in RAM
def heavy_computation(n: int) -> dict:
    """
    Simulates an expensive operation (e.g. ML model inference).
    lru_cache stores the result after first call.
    Same n value = instant return from cache. Different n = computed fresh.
    """
    print(f"[CACHE MISS] Computing for n={n} ... (takes 3s)")
    time.sleep(3)            # Simulate ML inference latency
    return {"input": n, "result": n * n, "computed_at": time.time()}


# ── Routes ──────────────────────────────────────────────────────
@app.get("/compute")
def compute(n: int):
    """
    Try calling this twice with the same n — second call is instant!
    """
    start = time.time()
    result = heavy_computation(n)
    elapsed = round(time.time() - start, 3)

    return {
        **result,
        "elapsed_seconds": elapsed,
        "from_cache": elapsed < 0.1,    # True if returned instantly
    }


@app.get("/cache-info")
def cache_info():
    """Shows lru_cache statistics — hits, misses, current size."""
    info = heavy_computation.cache_info()
    return {
        "hits":     info.hits,      # Times result returned from cache
        "misses":   info.misses,    # Times actual computation ran
        "maxsize":  info.maxsize,   # Max entries allowed
        "currsize": info.currsize,  # Currently cached entries
    }


@app.delete("/clear-cache")
def clear_cache():
    """Clears the entire cache — next call will recompute."""
    heavy_computation.cache_clear()
    return {"message": "Cache cleared!"}


@app.get("/health")
def health():
    return {"status": "ok", "demo": "lru_cache"}
